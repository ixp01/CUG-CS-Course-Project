#include "mainwindow.h"

#include <QApplication>
#include <QTextCodec>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    
    // 设置全局字体和样式
    QFont font("Microsoft YaHei", 9);
    a.setFont(font);
    
    // 设置编码，以支持中文
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
    
    MainWindow w;
    w.show();
    return a.exec();
}
