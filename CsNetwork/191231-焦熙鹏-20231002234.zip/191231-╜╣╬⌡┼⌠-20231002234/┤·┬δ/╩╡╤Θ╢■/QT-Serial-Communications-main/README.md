# QT-Serial-Communications
利用QT写的串口助手，实现简单的串口通信
，在自己电脑运行的时候需要把test_mainwindow里面的user文件删除才可以顺利运行

![serial](https://user-images.githubusercontent.com/108324825/222351151-cd7de088-fc4e-4d72-bbcd-66d939e5934a.png)
