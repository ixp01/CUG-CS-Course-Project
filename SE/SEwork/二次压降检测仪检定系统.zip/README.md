
  # 二次压降检测仪检定系统

  This is a code bundle for 二次压降检测仪检定系统. The original project is available at https://www.figma.com/design/2L6Ob6Cd5OYihMhUUFvIdx/%E4%BA%8C%E6%AC%A1%E5%8E%8B%E9%99%8D%E6%A3%80%E6%B5%8B%E4%BB%AA%E6%A3%80%E5%AE%9A%E7%B3%BB%E7%BB%9F.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  